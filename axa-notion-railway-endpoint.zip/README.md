# AXA Notion Endpoint (Railway)

Endpoint minimal para crear subpáginas o items en bases de datos de Notion usando tu integración **AXA Automatizations HQ**.

## 1) Deploy en Railway
1. Crea cuenta en https://railway.app y un proyecto vacío.
2. Sube estos archivos (o conecta un repo).
3. En **Variables** agrega:
   - `NOTION_TOKEN` = tu Internal Integration Token de Notion.
   - Opcional:
     - `ALLOWLIST_PAGE_IDS` = IDs de páginas permitidas, separados por coma.
     - `ALLOWLIST_DATABASE_IDS` = IDs de bases permitidas, separados por coma.
4. Deploy. Copia la URL pública (ej: `https://<project>.up.railway.app`).

## 2) Endpoints

### Health
GET `/health` → `{ ok: true }`

### Crear subpágina
POST `/notion`
```json
{
  "mode": "page",
  "title": "AXA — Test Global 🚀",
  "parentPageId": "2645321879eb801e9324c8a61b56d220"
}
```

### Crear item en base de datos
POST `/notion`
```json
{
  "mode": "database",
  "title": "AXA Test – Verificación Control",
  "databaseId": "2625321879eb801c93d8ed0218dca4d1",
  "properties": {
    "Estado":  { "select": { "name": "Prueba" } },
    "Ejemplo": { "rich_text": [ { "text": { "content": "" } } ] }
  }
}
```

> El servidor detecta automáticamente cuál es la **propiedad título** real de tu DB.

## 3) Seguridad
- No pongas el token en el código. Usa **Variables** en Railway.
- Usa `ALLOWLIST_*` para limitar dónde puede escribir.