// server.js - Railway Endpoint for Notion (AXA Automatizations HQ)
const express = require("express");
const { Client } = require("@notionhq/client");

const app = express();
app.use(express.json({ limit: "1mb" }));

const PORT = process.env.PORT || 3000;
const NOTION_TOKEN = process.env.NOTION_TOKEN;

// Optional allowlists (comma-separated IDs)
const ALLOWLIST_PAGE_IDS = (process.env.ALLOWLIST_PAGE_IDS || "")
  .split(",")
  .map(s => s.trim())
  .filter(Boolean);

const ALLOWLIST_DATABASE_IDS = (process.env.ALLOWLIST_DATABASE_IDS || "")
  .split(",")
  .map(s => s.trim())
  .filter(Boolean);

function assertEnv() {
  if (!NOTION_TOKEN) {
    const err = new Error("Missing NOTION_TOKEN env var");
    err.status = 500;
    throw err;
  }
}

function guardAccess({ parentPageId, databaseId }) {
  const useAllow = ALLOWLIST_PAGE_IDS.length > 0 || ALLOWLIST_DATABASE_IDS.length > 0;
  if (!useAllow) return; // no guards enabled

  if (databaseId && !ALLOWLIST_DATABASE_IDS.includes(databaseId)) {
    const err = new Error("databaseId not allowed");
    err.status = 403;
    throw err;
  }
  if (parentPageId && !ALLOWLIST_PAGE_IDS.includes(parentPageId)) {
    const err = new Error("parentPageId not allowed");
    err.status = 403;
    throw err;
  }
}

app.get("/", (req, res) => {
  res.json({ ok: true, service: "AXA Notion Endpoint", now: new Date().toISOString() });
});

app.get("/health", (req, res) => res.json({ ok: true }));

app.post("/notion", async (req, res) => {
  try {
    assertEnv();
    const notion = new Client({ auth: NOTION_TOKEN });

    const {
      mode = "page", // "page" | "database"
      title = "AXA — Test Global 🚀",
      parentPageId,
      databaseId,
      properties = {},
      content = []
    } = req.body || {};

    guardAccess({ parentPageId, databaseId });

    if (mode === "database") {
      if (!databaseId) {
        return res.status(400).json({ ok: false, error: "databaseId is required for mode=database" });
      }
      // Detect real title property key of the database
      const db = await notion.databases.retrieve({ database_id: databaseId });
      const titlePropKey = Object.keys(db.properties).find(
        k => db.properties[k]?.type === "title"
      );
      if (!titlePropKey) {
        return res.status(500).json({ ok: false, error: "Database has no title property" });
      }
      const created = await notion.pages.create({
        parent: { database_id: databaseId },
        properties: {
          [titlePropKey]: { title: [{ text: { content: title } }] },
          ...properties
        }
      });
      return res.json({ ok: true, type: "database_item", id: created.id, url: created.url });
    }

    // Default: create a subpage under a page
    if (!parentPageId) {
      return res.status(400).json({ ok: false, error: "parentPageId is required for mode=page" });
    }
    const created = await notion.pages.create({
      parent: { page_id: parentPageId },
      properties: {
        title: { title: [{ text: { content: title } }] }
      },
      children: content
    });
    return res.json({ ok: true, type: "page", id: created.id, url: created.url });
  } catch (e) {
    const status = e.status || 500;
    console.error("Error:", e.body || e.message || e);
    return res.status(status).json({ ok: false, error: e.body || e.message || "Unknown error" });
  }
});

app.listen(PORT, () => {
  console.log(`AXA Notion Endpoint running on port ${PORT}`);
});